
#ifndef _EXTRNRESOLVER_H_
#define _EXTRNRESOLVER_H_ 1

#ifndef __cplusplus
#error C++ compiler required.
#endif

#include "rtrlist.hpp"

namespace RTR {

bool Execute();
extern CRTRList rtr_list;

}

#endif // _EXTRNRESOLVER_H_
