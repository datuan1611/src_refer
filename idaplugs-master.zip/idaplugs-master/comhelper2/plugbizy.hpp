
/*****************************************************************************
 *                                                                           *
 *  plugbizy.hpp: auto-analysis running wait dialog                          *
 *  (c) 2003-2008 servil                                                     *
 *                                                                           *
 *****************************************************************************/

#ifndef _PLUGBIZY_HPP_
#define _PLUGBIZY_HPP_ 1

#define NOMINMAX 1
#include <wtypes.h>

bool decide_ida_bizy(LPCSTR title = NULL, LPCSTR message = NULL);

#endif // _PLUGBIZY_HPP_
