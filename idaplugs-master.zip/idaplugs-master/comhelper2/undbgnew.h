
#ifdef new
#undef new
#endif // new
